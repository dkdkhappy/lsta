====================================================

 Santhony font is FREE for PERSONAL & COMMERCIAL USE

====================================================

But any donation is very appreciated.
Paypal account for donation: https://paypal.me/jadaakbal

Thank you and happy using!
Jadatype